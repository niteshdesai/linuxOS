/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Ashwin
 */
public class Farmer {

    private int farmerId;
    private String fname;
    private String mname;
    private String lname;
    private String mobile;
    private String email;
    private String gender;
    private String address;
    private String regDate;
    private String password;
    private String role;
    private String profImg;

    // Default constructor
    public Farmer() {
    }

    // Parameterized constructor
    public Farmer(int farmerId, String fname, String mname, String lname,
            String mobile, String email, String gender, String address, String regDate,
            String password, String role,String profImg) {
        this.farmerId = farmerId;
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
        this.mobile = mobile;
        this.email = email;
        this.gender = gender;
        this.address = address;
        this.regDate = regDate;
        this.password = password;
        this.role = role;
        this.profImg=profImg;
    }

    public String getProfImg() {
        return profImg;
    }

    public void setProfImg(String profImg) {
        this.profImg = profImg;
    }

//    public Farmer(int farmerId, String fname, String mname, String lname, String mobile,
//            String email, String gender, String address, String regDate, String password) {
//        this.farmerId = farmerId;
//        this.fname = fname;
//        this.mname = mname;
//        this.lname = lname;
//        this.mobile = mobile;
//        this.email = email;
//        this.gender = gender;
//        this.address = address;
//        this.regDate = regDate;
//        this.password = password;
//        
//    }

    // Getters and Setters
    public int getFarmerId() {
        return farmerId;
    }

    public void setFarmerId(int farmerId) {
        this.farmerId = farmerId;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRegDate() {
        return regDate;
    }

    public void setRegDate(String regDate) {
        this.regDate = regDate;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
   public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    // toString method for easy printing of object details
    @Override
    public String toString() {
        return "Farmer{"
                + "farmerId=" + farmerId
                + ", fname='" + fname + '\''
                + ", mname='" + mname + '\''
                + ", lname='" + lname + '\''
                + ", mobile='" + mobile + '\''
                + ", email='" + email + '\''
                + ", gender='" + gender + '\''
                + ", address='" + address + '\''
                + ", regDate='" + regDate + '\''
                + '}';
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Ashwin
 */


public class MachineRequest{
    private int mreqId;             // optional if auto-increment
    private int mreqFrmrId;
    private int catId;
    private String mreqStatus;
     private String mreDuration;
     private String mreqDatetime;
     private int mreqOwnerId;

    public MachineRequest(int mreqId, int mreqFrmrId, int catId, String mreqStatus, String mreDuration, String mreqDatetime, int mreqOwnerId, String mreqLocation) {
        this.mreqId = mreqId;
        this.mreqFrmrId = mreqFrmrId;
        this.catId = catId;
        this.mreqStatus = mreqStatus;
        this.mreDuration = mreDuration;
        this.mreqDatetime = mreqDatetime;
        this.mreqOwnerId = mreqOwnerId;
        this.mreqLocation = mreqLocation;
    }

    public int getMreqOwnerId() {
        return mreqOwnerId;
    }

    public void setMreqOwnerId(int mreqOwnerId) {
        this.mreqOwnerId = mreqOwnerId;
    }

    public String getMreDuration() {
        return mreDuration;
    }

    public void setMreDuration(String mreDuration) {
        this.mreDuration = mreDuration;
    }
    private String mreqLocation;   


    public MachineRequest() {
        this.mreqStatus = "pending";
    }

    public int getMreqId() {
        return mreqId;
    }

    public void setMreqId(int mreqId) {
        this.mreqId = mreqId;
    }

    public int getMreqFrmrId() {
        return mreqFrmrId;
    }

    public void setMreqFrmrId(int mreqFrmrId) {
        this.mreqFrmrId = mreqFrmrId;
    }

    public int getCatId() {
        return catId;
    }

    public void setCatId(int catId) {
        this.catId = catId;
    }

    public String getMreqStatus() {
        return mreqStatus;
    }

    public void setMreqStatus(String mreqStatus) {
        this.mreqStatus = mreqStatus;
    }

    public String getMreqDatetime() {
        return mreqDatetime;
    }

    public void setMreqDatetime(String mreqDatetime) {
        this.mreqDatetime = mreqDatetime;
    }

    public String getMreqLocation() {
        return mreqLocation;
    }

    public void setMreqLocation(String mreqLocation) {
        this.mreqLocation = mreqLocation;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Ashwin
 */
public class VehicleOwner {
    private int ownerId;
    private String ownerFname;
    private String ownerMname;
    private String ownerLname;
    private String ownerMobile;
    private String ownerEmail;
    private String ownerGender;
    private String ownerAddress;
    private String ownerRegDate;
   private String password;
    private String role;
    private String profImg;

    public VehicleOwner(int ownerId, String ownerFname, String ownerMname, String ownerLname, String ownerMobile, String ownerEmail, String ownerGender, String ownerAddress, String ownerRegDate, String password, String role, String profImg) {
        this.ownerId = ownerId;
        this.ownerFname = ownerFname;
        this.ownerMname = ownerMname;
        this.ownerLname = ownerLname;
        this.ownerMobile = ownerMobile;
        this.ownerEmail = ownerEmail;
        this.ownerGender = ownerGender;
        this.ownerAddress = ownerAddress;
        this.ownerRegDate = ownerRegDate;
        this.password = password;
        this.role = role;
        this.profImg = profImg;
    }

    // Default constructor
    public VehicleOwner() {
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getProfImg() {
        return profImg;
    }

    public void setProfImg(String profImg) {
        this.profImg = profImg;
    }


    // Getters and Setters
    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    public String getOwnerFname() {
        return ownerFname;
    }

    public void setOwnerFname(String ownerFname) {
        this.ownerFname = ownerFname;
    }

    public String getOwnerMname() {
        return ownerMname;
    }

    public void setOwnerMname(String ownerMname) {
        this.ownerMname = ownerMname;
    }

    public String getOwnerLname() {
        return ownerLname;
    }

    public void setOwnerLname(String ownerLname) {
        this.ownerLname = ownerLname;
    }

    public String getOwnerMobile() {
        return ownerMobile;
    }

    public void setOwnerMobile(String ownerMobile) {
        this.ownerMobile = ownerMobile;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getOwnerGender() {
        return ownerGender;
    }

    public void setOwnerGender(String ownerGender) {
        this.ownerGender = ownerGender;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public String getOwnerRegDate() {
        return ownerRegDate;
    }

    public void setOwnerRegDate(String ownerRegDate) {
        this.ownerRegDate = ownerRegDate;
    }

    // Optional: toString method for easy printing of object details
    @Override
    public String toString() {
        return "VehicleOwner{" +
                "ownerId=" + ownerId +
                ", ownerFname='" + ownerFname + '\'' +
                ", ownerMname='" + ownerMname + '\'' +
                ", ownerLname='" + ownerLname + '\'' +
                ", ownerMobile='" + ownerMobile + '\'' +
                ", ownerEmail='" + ownerEmail + '\'' +
                ", ownerGender='" + ownerGender + '\'' +
                ", ownerAddress='" + ownerAddress + '\'' +
                ", ownerRegDate='" + ownerRegDate + '\'' +
                '}';
    }
}

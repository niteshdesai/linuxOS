/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import java.util.Date;

/**
 *
 * @author pc
 */
public class Vehicle {
    int Mid;
    String mName;
    int mCatgoryId;
    String mModel;
    Date mAddDate;
    String mNumbe;
    String category;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Vehicle(int Mid, String mName, int mCatgoryId, String mModel, Date mAddDate, String mNumbe, String category, int mOwnerId, String mImage) {
        this.Mid = Mid;
        this.mName = mName;
        this.mCatgoryId = mCatgoryId;
        this.mModel = mModel;
        this.mAddDate = mAddDate;
        this.mNumbe = mNumbe;
        this.category = category;
        this.mOwnerId = mOwnerId;
        this.mImage = mImage;
    }

    public Vehicle() {
    }
    int mOwnerId;
    String mImage;

    public int getMid() {
        return Mid;
    }

    public void setMid(int Mid) {
        this.Mid = Mid;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public int getmCatgoryId() {
        return mCatgoryId;
    }

    public void setmCatgoryId(int mCatgoryId) {
        this.mCatgoryId = mCatgoryId;
    }

    public String getmModel() {
        return mModel;
    }

    public void setmModel(String mModel) {
        this.mModel = mModel;
    }

    public Date getmAddDate() {
        return mAddDate;
    }

    public void setmAddDate(Date mAddDate) {
        this.mAddDate = mAddDate;
    }

    public String getmNumbe() {
        return mNumbe;
    }

    public void setmNumbe(String mNumbe) {
        this.mNumbe = mNumbe;
    }

    public int getmOwnerId() {
        return mOwnerId;
    }

    public void setmOwnerId(int mOwnerId) {
        this.mOwnerId = mOwnerId;
    }

    public String getmImage() {
        return mImage;
    }

    public void setmImage(String mImage) {
        this.mImage = mImage;
    }

    public Vehicle(int Mid, String mName, int mCatgoryId, String mModel, Date mAddDate, String mNumbe, int mOwnerId, String mImage) {
        this.Mid = Mid;
        this.mName = mName;
        this.mCatgoryId = mCatgoryId;
        this.mModel = mModel;
        this.mAddDate = mAddDate;
        this.mNumbe = mNumbe;
        this.mOwnerId = mOwnerId;
        this.mImage = mImage;
    }
    
}

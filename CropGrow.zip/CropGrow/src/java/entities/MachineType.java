/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Ashwin
 */
public class MachineType {

    private int mcId;
    private String mcName;
    private String mcUse;
    private String mcImg;
    private double mc_rate;

    // Default constructor
    public MachineType() {
    }

    // Parameterized constructor
    public MachineType(int mcId, String mcName, String mcUse, String mcImg, double mc_rate) {
        this.mcId = mcId;
        this.mcName = mcName;
        this.mcUse = mcUse;
        this.mcImg = mcImg;
        this.mc_rate = mc_rate;
    }

    // Getters and Setters
    public int getMcId() {
        return mcId;
    }

    public void setMcId(int mcId) {
        this.mcId = mcId;
    }

    public String getMcName() {
        return mcName;
    }

    public void setMcName(String mcName) {
        this.mcName = mcName;
    }

    public String getMcUse() {
        return mcUse;
    }

    public void setMcUse(String mcUse) {
        this.mcUse = mcUse;
    }

    public String getMcImg() {
        return mcImg;
    }

    public void setMcImg(String mcImg) {
        this.mcImg = mcImg;
    }

    public double getMc_rate() {
        return mc_rate;
    }

    public void setMc_rate(double mc_rate) {
        this.mc_rate = mc_rate;
    }
}

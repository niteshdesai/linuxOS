/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Ashwin
 */
import entities.Farmer;
import entities.VehicleOwner;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VehicleOwnerDAOImpl {

    private Connection connection;

    // Constructor to inject database connection
    public VehicleOwnerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    public void registerVehicleOwner(VehicleOwner owner) {
        String query = "INSERT INTO machine_owner_registration (owner_id, owner_fname, owner_mname, owner_lname, owner_mobile, owner_email, owner_gender, owner_address, owner_reg_date) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, owner.getOwnerId());
            ps.setString(2, owner.getOwnerFname());
            ps.setString(3, owner.getOwnerMname());
            ps.setString(4, owner.getOwnerLname());
            ps.setString(5, owner.getOwnerMobile());
            ps.setString(6, owner.getOwnerEmail());
            ps.setString(7, owner.getOwnerGender());
            ps.setString(8, owner.getOwnerAddress());
            ps.setString(9, owner.getOwnerRegDate());
            ps.executeUpdate();
            System.out.println("Vehicle owner registered successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error registering vehicle owner: " + e.getMessage());
        }
    }

    public VehicleOwner findById(int ownerId) {
        String query = "SELECT * FROM registration WHERE  farmer_id= ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, ownerId);
            var rs = ps.executeQuery();
            if (rs.next()) {
                return new VehicleOwner(
                       rs.getInt("farmer_id"),
                        rs.getString("fname"),
                        rs.getString("mname"),
                        rs.getString("lname"),
                        rs.getString("mobile"),
                        rs.getString("email"),
                        rs.getString("gender"),
                        rs.getString("address"),
                        rs.getString("reg_date"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("profile_img")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //Edit owner detail
    public boolean updateDataById(VehicleOwner owner) {
    String query = "UPDATE registration SET fname = ?, mname = ?, lname = ?, mobile = ?, gender = ?, address = ? WHERE farmer_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
        ps.setString(1, owner.getOwnerFname());
        ps.setString(2, owner.getOwnerMname());
        ps.setString(3, owner.getOwnerLname());
        ps.setString(4, owner.getOwnerMobile());
        ps.setString(5, owner.getOwnerGender());
        ps.setString(6, owner.getOwnerAddress());
        ps.setInt(7, owner.getOwnerId());

        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}
     public String getProfileImageName(int fid) {
        String sql = "SELECT profile_img FROM registration WHERE farmer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, fid);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("profile_img");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if not found
    }
      public boolean changeProfileImg(int fid, String imgName) {
        String sql = "UPDATE registration SET profile_img = ? WHERE farmer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, imgName);
            stmt.setInt(2, fid);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
      
       public int countAvailableMachines(int ownerId) {
       
        
        try {
            
            String query = "SELECT COUNT(am_id) FROM available_machines WHERE am_owner_id = ? ";
            
            PreparedStatement pstmt = this.connection.prepareStatement(query);
            pstmt.setInt(1, ownerId);
            
           return pstmt.executeUpdate();
           
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Ashwin
 */
import entities.MachineType;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MachineTypeDaoImpl {

    private Connection conn;

    // Constructor to inject the connection
    public MachineTypeDaoImpl(Connection conn) {
        this.conn = conn;
    }

    public int addMachineType(MachineType machine) {
        int status = 0;
        String sql = "INSERT INTO machine_category (mc_name, mc_use, mc_img, mc_rate) VALUES ( ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, machine.getMcName());
            ps.setString(2, machine.getMcUse());
            ps.setString(3, machine.getMcImg());
            ps.setDouble(4, machine.getMc_rate());

            status = ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return status;
    }

    public List<MachineType> getAllMachineTypes() {
        List<MachineType> list = new ArrayList<>();
        String sql = "SELECT * FROM machine_category";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MachineType m = new MachineType();
                m.setMcId(rs.getInt("mc_id"));
                m.setMcName(rs.getString("mc_name"));
                m.setMcUse(rs.getString("mc_use"));
                m.setMcImg(rs.getString("mc_img"));
                m.setMc_rate(rs.getDouble("mc_rate"));
                list.add(m);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public MachineType getMachineTypeById(int mcId) {
        MachineType machine = null;
        String sql = "SELECT * FROM machine_category WHERE mc_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, mcId);

            try (ResultSet rs = ps.executeQuery()) {
              
                if (rs.next()) {
                   
                    machine = new MachineType();
                    machine.setMcId(rs.getInt("mc_id"));
                    machine.setMcName(rs.getString("mc_name"));
                    machine.setMcUse(rs.getString("mc_use"));
                    machine.setMcImg(rs.getString("mc_img"));
                    machine.setMc_rate(rs.getDouble("mc_rate"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return machine;
    }

    public boolean updateMachineType(MachineType machineType) {
        boolean success = false;
        String query = "UPDATE machine_category SET mc_name = ?, mc_use = ?, mc_rate = ? WHERE mc_id = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, machineType.getMcName());
            pstmt.setString(2, machineType.getMcUse());
            pstmt.setDouble(3, machineType.getMc_rate());
            pstmt.setInt(4, machineType.getMcId());
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return success;
    }


    public int deleteMachineType(int mcId) {
        int status = 0;
        String sql = "DELETE FROM machine_category WHERE mcId = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, mcId);
            status = ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return status;
    }
}

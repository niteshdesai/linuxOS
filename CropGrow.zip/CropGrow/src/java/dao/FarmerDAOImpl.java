/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Ashwin
 */
import entities.Farmer;
import helper.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class FarmerDAOImpl {

    private Connection connection;

    // Constructor to inject database connection
    public FarmerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    public boolean registerFarmer(Farmer farmer) {
        String query = "INSERT INTO registration (fname, mname, lname, mobile, email, gender, address,password,role) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, farmer.getFname());
            ps.setString(2, farmer.getMname());
            ps.setString(3, farmer.getLname());
            ps.setString(4, farmer.getMobile());
            ps.setString(5, farmer.getEmail());
            ps.setString(6, farmer.getGender());
            ps.setString(7, farmer.getAddress());
            ps.setString(8, farmer.getPassword());
            ps.setString(9, farmer.getRole());
            ps.executeUpdate();
            System.out.println("Farmer registered successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error registering farmer: " + e.getMessage());
        }
        return true;
    }

    public boolean isEmailExists(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM registration WHERE email = ?";

        try (Connection conn = ConnectionProvider.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        }
    }

    public Farmer findByEmail(String email) {
        String query = "SELECT * FROM registration WHERE email = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Farmer(
                        rs.getInt("farmer_id"),
                        rs.getString("fname"),
                        rs.getString("mname"),
                        rs.getString("lname"),
                        rs.getString("mobile"),
                        rs.getString("email"),
                        rs.getString("gender"),
                        rs.getString("address"),
                        rs.getString("reg_date"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("profile_img")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Farmer findById(int id) {
    String query = "SELECT * FROM registration WHERE farmer_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return new Farmer(
                    rs.getInt("farmer_id"),
                    rs.getString("fname"),
                    rs.getString("mname"),
                    rs.getString("lname"),
                    rs.getString("mobile"),
                    rs.getString("email"),
                    rs.getString("gender"),
                    rs.getString("address"),
                    rs.getString("reg_date"),
                    rs.getString("password"),
                    rs.getString("role"),
                    rs.getString("profile_img")
                    
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}
//Update Farmer profile data
    public boolean updateDataById(Farmer farmer) {
    String query = "UPDATE registration SET fname = ?, mname = ?, lname = ?, mobile = ?, gender = ?, address = ? WHERE farmer_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
        ps.setString(1, farmer.getFname());
        ps.setString(2, farmer.getMname());
        ps.setString(3, farmer.getLname());
        ps.setString(4, farmer.getMobile());
        ps.setString(5, farmer.getGender());
        ps.setString(6, farmer.getAddress());
        ps.setInt(7, farmer.getFarmerId());

        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}
    
    public String getProfileImageName(int fid) {
        String sql = "SELECT profile_img FROM registration WHERE farmer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, fid);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("profile_img");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if not found
    }
    
    public boolean changeProfileImg(int fid, String imgName) {
        String sql = "UPDATE registration SET profile_img = ? WHERE farmer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, imgName);
            stmt.setInt(2, fid);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entities.Farmer;
import entities.MachineRequest;
import java.sql.Connection;
import java.sql.*;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pc
 */
public class AdminDAOImpl {
    private Connection connection;

    public AdminDAOImpl(Connection connection) {
        this.connection = connection;
    }
    
    public List<MachineRequest> geAlltRequest() {
    List<MachineRequest> requests = new ArrayList<>();

    String sql = "SELECT * FROM machine_booking_request";

    try (Statement st = connection.createStatement();) {
        
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            MachineRequest mr = new MachineRequest();
            mr.setMreqId(rs.getInt("mreq_id"));
            mr.setMreqFrmrId(rs.getInt("mreq_frmr_id"));
            mr.setCatId(rs.getInt("cat_id"));
            mr.setMreqStatus(rs.getString("mreq_status"));
            mr.setMreqLocation(rs.getString("mreq_location"));
            mr.setMreDuration(rs.getString("mreq_duration"));
            mr.setMreqDatetime(rs.getString("mreq_datetime")); // if your class has this
            requests.add(mr);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return requests;
}
    
    public List<Farmer> getAllFarmer() {
        List<Farmer> farmers = new ArrayList<>();
    String query = "SELECT * FROM registration WHERE role = 'Farmer' ";
    try (Statement st = connection.createStatement();) {
      
        ResultSet rs = st.executeQuery(query);
        if (rs.next()) {
           
              Farmer farmer=new Farmer (
                    rs.getInt("farmer_id"),
                    rs.getString("fname"),
                    rs.getString("mname"),
                    rs.getString("lname"),
                    rs.getString("mobile"),
                    rs.getString("email"),
                    rs.getString("gender"),
                    rs.getString("address"),
                    rs.getString("reg_date"),
                    rs.getString("password"),
                    rs.getString("role"),
                    rs.getString("profile_img")
                    
            );
             farmers.add(farmer);
           return farmers;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return null;
}
     public List<Farmer> getAllOwner() {
        List<Farmer> farmers = new ArrayList<>();
    String query = "SELECT * FROM registration WHERE role = 'Machine Owner' ";
    try (Statement st = connection.createStatement();) {
      
        ResultSet rs = st.executeQuery(query);
        if (rs.next()) {
           
              Farmer farmer=new Farmer (
                    rs.getInt("farmer_id"),
                    rs.getString("fname"),
                    rs.getString("mname"),
                    rs.getString("lname"),
                    rs.getString("mobile"),
                    rs.getString("email"),
                    rs.getString("gender"),
                    rs.getString("address"),
                    rs.getString("reg_date"),
                    rs.getString("password"),
                    rs.getString("role"),
                    rs.getString("profile_img")
                    
            );
             farmers.add(farmer);
           return farmers;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } 
    return null;
     }
     
      public boolean updateCategoryImage(int mcId, String imageName) {
        boolean success = false;
        String query = "UPDATE machine_category SET mc_img = ? WHERE mc_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, imageName);
            pstmt.setInt(2, mcId);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return success;
    }
}

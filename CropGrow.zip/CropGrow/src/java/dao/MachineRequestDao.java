/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import entities.MachineRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
/**
 *
 * @author Ashwin
 */
public class MachineRequestDao {
      private final Connection conn;

    public MachineRequestDao(Connection conn) {
        this.conn = conn;
    }

   public boolean insertMachineRequest(MachineRequest mr) {
    boolean result = false;

    String sql = "INSERT INTO machine_booking_request(mreq_frmr_id, cat_id, mreq_status, mreq_location,mreq_duration) VALUES (?, ?, ?, ?,?)";

    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, mr.getMreqFrmrId());
        ps.setInt(2, mr.getCatId());
        ps.setString(3, mr.getMreqStatus());
        ps.setString(4, mr.getMreqLocation());
        ps.setString(5, mr.getMreDuration());
        int rows = ps.executeUpdate();
        result = rows == 1;
    } catch (Exception e) {
        e.printStackTrace();
    }

    return result;
}
   public List<MachineRequest> getRequestById(int fId) {
    List<MachineRequest> requests = new ArrayList<>();

    String sql = "SELECT * FROM machine_booking_request WHERE mreq_frmr_id = ?";

    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, fId);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            MachineRequest mr = new MachineRequest();
            mr.setMreqId(rs.getInt("mreq_id"));
            mr.setMreqFrmrId(rs.getInt("mreq_frmr_id"));
            mr.setCatId(rs.getInt("cat_id"));
            mr.setMreqStatus(rs.getString("mreq_status"));
            mr.setMreqLocation(rs.getString("mreq_location"));
            mr.setMreDuration(rs.getString("mreq_duration"));
            mr.setMreqDatetime(rs.getString("mreq_datetime")); // if your class has this
            requests.add(mr);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return requests;
}
   
   public List<MachineRequest> getPendinggRequest(int ownerId) {
    List<MachineRequest> requests = new ArrayList<>();

//    String sql = "SELECT * FROM machine_booking_request WHERE  mreq_status= 'pending'";
 String sql="SELECT mbr.* FROM machine_booking_request mbr WHERE mbr.mreq_status = 'pending' AND mbr.mreq_id NOT IN (SELECT mreq_id FROM machin_request_reject WHERE farmer_id = "+ownerId+")";
    try (Statement stmt=conn.createStatement();) {
//        ps.setString(1, "pending");
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            MachineRequest mr = new MachineRequest();
            mr.setMreqId(rs.getInt("mreq_id"));
            mr.setMreqFrmrId(rs.getInt("mreq_frmr_id"));
            mr.setCatId(rs.getInt("cat_id"));
            mr.setMreqStatus(rs.getString("mreq_status"));
            mr.setMreqLocation(rs.getString("mreq_location"));
            mr.setMreDuration(rs.getString("mreq_duration"));
            mr.setMreqDatetime(rs.getString("mreq_datetime")); 
            mr.setMreqOwnerId(rs.getInt("mreq_owneId")); 
            requests.add(mr);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return requests;
}
      public List<MachineRequest> getConfirmRequest(int ownerId) {
    List<MachineRequest> requests = new ArrayList<>();

    String sql = "SELECT * FROM machine_booking_request WHERE  mreq_status= 'confirm' AND mreq_owneId=? ";

    try (PreparedStatement ps=conn.prepareStatement(sql)) {
        ps.setInt(1, ownerId);
        
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            MachineRequest mr = new MachineRequest();
            mr.setMreqId(rs.getInt("mreq_id"));
            mr.setMreqFrmrId(rs.getInt("mreq_frmr_id"));
            mr.setCatId(rs.getInt("cat_id"));
            mr.setMreqStatus(rs.getString("mreq_status"));
            mr.setMreqLocation(rs.getString("mreq_location"));
            mr.setMreDuration(rs.getString("mreq_duration"));
            mr.setMreqDatetime(rs.getString("mreq_datetime")); 
            mr.setMreqOwnerId(rs.getInt("mreq_owneId")); 
            requests.add(mr);
            
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return requests;
}
      
      public boolean onRequestAccept(int ownerId, int bookingId)
      {
          
          try {
               String sql = "UPDATE machine_booking_request SET mreq_status = ?, mreq_owneId = ? WHERE mreq_id = ? ";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "confirm");
            ps.setInt(2, ownerId);
            ps.setInt(3, bookingId);

            int rowsAffected = ps.executeUpdate();

            return rowsAffected > 0 ;
                
          } catch (Exception e) {
              e.printStackTrace();
          }
          return false;
          }
    public boolean onRequestReject(int ownerId, int bookingId)
      {
          
          try {
              
            String sqlInsert = "INSERT INTO machin_request_reject (mreq_id, farmer_id) VALUES (?, ?)";
            PreparedStatement psInsert=conn.prepareStatement(sqlInsert);
           
            psInsert.setInt(1, bookingId);
            psInsert.setInt(2, ownerId);

            return  psInsert.executeUpdate()>0;
                
          } catch (Exception e) {
              e.printStackTrace();
          }
          return false;
          }
      
}

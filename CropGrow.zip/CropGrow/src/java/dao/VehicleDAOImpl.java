/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entities.MachineType;
import entities.Vehicle;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author pc
 */

public class VehicleDAOImpl {
    private Connection connection;
   
    
    public VehicleDAOImpl(Connection connection) {
        this.connection = connection;
    }
    public List<Vehicle> getMachineById(int ownerId)
    {
        List<Vehicle> vehicles=new ArrayList<>();
        try {
            String query="SELECT * FROM available_machines WHERE am_owner_id=?";
            
            PreparedStatement pst=connection.prepareStatement(query);
            pst.setInt(1, ownerId);
            ResultSet rs=pst.executeQuery();
            pst=connection.prepareStatement("SELECT mc_name FROM available_machines WHERE mc_id=?");
            
            MachineTypeDaoImpl mcdao=new MachineTypeDaoImpl(connection);
            while(rs.next())
            {
             
             Vehicle vehicle=new Vehicle();
             vehicle.setMid(rs.getInt("am_id"));
             vehicle.setmName(rs.getString("am_name"));
              
             MachineType mcType=mcdao.getMachineTypeById(rs.getInt("category_id"));
             
             vehicle.setCategory(mcType.getMcName());
             vehicle.setmModel(rs.getString("am_machine_model"));
             vehicle.setmAddDate(rs.getDate("am_add_date"));
             vehicle.setmNumbe(rs.getString("am_number"));
             vehicle.setmOwnerId(rs.getInt("am_owner_id"));
             vehicle.setmImage(rs.getString("am_image"));
             vehicles.add(vehicle);     
           
            }
              return vehicles; 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vehicles;
    }
    
    
    public boolean AddMachineDetail(Vehicle vehicle)
    {
        try {
              
        String query="INSERT INTO available_machines(`am_name`,`category_id`,`am_machine_model`,`am_number`,`am_owner_id`)VALUES(?,?,?,?,?)";
            
            PreparedStatement pst=connection.prepareStatement(query);
            pst.setString(1, vehicle.getmName());
            pst.setInt(2, vehicle.getmCatgoryId());
            pst.setString(3, vehicle.getmModel());
            pst.setString(4, vehicle.getmNumbe());
            pst.setInt(5, vehicle.getmOwnerId());
            
           
             return pst.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
      return false;
    }
    
    public String getCategoryName(int id)
    {
        try {
             String query="SELECT mc_name FROM machine_category WHERE mc_id=?";
            
            PreparedStatement pst=connection.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs=pst.executeQuery();
            rs.next();
             return rs.getString("mc_name");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
   
    public boolean UpdateTractorDetail(Vehicle vehicle)
    {
         String query = "UPDATE available_machines SET am_name = ?, category_id = ?, am_machine_model = ?, am_number = ?, am_owner_id = ? WHERE am_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
        ps.setString(1, vehicle.getmName());
        ps.setInt(2, vehicle.getmCatgoryId());
        ps.setString(3, vehicle.getmModel());
        ps.setString(4, vehicle.getmNumbe());
        ps.setInt(5, vehicle.getmOwnerId());
        ps.setInt(6, vehicle.getMid());
        return ps.executeUpdate() > 0;

    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
return false;
}
     public boolean UpdateMachineImage(int mid,String image)
    {
        String sql = "UPDATE available_machines SET am_image = ? WHERE am_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) 
    {
            ps.setString(1, image);
            ps.setInt(2, mid);
            return ps.executeUpdate() > 0;

    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
return false;
}
}

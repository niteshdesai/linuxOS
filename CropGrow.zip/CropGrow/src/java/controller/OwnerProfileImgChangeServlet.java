/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.FarmerDAOImpl;
import dao.VehicleOwnerDAOImpl;
import helper.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.json.JSONObject;

/**
 *
 * @author pc
 */
@WebServlet(name = "OwnerProfileImgChangeServlet", urlPatterns = {"/OwnerProfileImgChangeServlet"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB

public class OwnerProfileImgChangeServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  private static final String UPLOAD_DIR = "img";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            int ownerId = Integer.parseInt(request.getParameter("ownerId"));
              
//             Get the uploaded file
            Part filePart = request.getPart("profileImage");
            String fileName = filePart.getSubmittedFileName();
            if (fileName == null || fileName.isEmpty()) {
                throw new IOException("No file uploaded");
            }



            // Save the file
            String filePath = "D:/CropGro/CropGrow/CropGrow/web/img/" + File.separator + fileName;
            filePart.write(filePath);
            
            VehicleOwnerDAOImpl vodao=new VehicleOwnerDAOImpl(ConnectionProvider.getConnection());
            JSONObject jsonResponse = new JSONObject();
            if(vodao.changeProfileImg(ownerId, fileName))
            {
                jsonResponse.put("status", "success");
                jsonResponse.put("message", "Profile image updated successfully.");
                jsonResponse.put("imageName", fileName);
            }
            else
            {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Failed to update profile image.");
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                // Optionally delete the uploaded file if update fails
                new File(filePath).delete();
            }
             out.print(jsonResponse.toString());
             
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.FarmerDAOImpl;
import entities.Farmer;
import entities.VehicleOwner;
import helper.ConnectionProvider;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;

/**
 *
 * @author Ashwin
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private FarmerDAOImpl farmerDAO;

    @Override
    public void init() throws ServletException {
        try {
            Connection con = ConnectionProvider.getConnection();
            farmerDAO = new FarmerDAOImpl(con);
        } catch (Exception e) {
        }

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Farmer farmer = farmerDAO.findByEmail(email);
            
            if (farmer != null && farmer.getPassword().equals(password)) { // Add hashing in production
                // Set session attribute
                HttpSession session = request.getSession();
                
                // Prepare JSON response with role-based redirection data
                String role = farmer.getRole();
                jsonResponse.put("success", true);
                jsonResponse.put("role", role.toLowerCase()); // Send role in lowercase for consistency
                
                // Set session attributes based on role
                if ("machine owner".equalsIgnoreCase(role)) { // Assuming "Machine Owner" from registration
                   
                    VehicleOwner owner=new VehicleOwner();
                     owner.setOwnerFname(farmer.getFname());
                     owner.setOwnerLname(farmer.getLname());
                     owner.setOwnerAddress(farmer.getAddress());
                     owner.setOwnerEmail(farmer.getEmail());
                     owner.setOwnerGender(farmer.getGender());
                     owner.setOwnerId(farmer.getFarmerId());
                     owner.setOwnerMobile(farmer.getMobile());
                     owner.setOwnerRegDate(farmer.getRegDate());
                     owner.setPassword(farmer.getPassword());
                     owner.setRole(farmer.getRole());
                     owner.setProfImg(farmer.getProfImg());
                    session.setAttribute("owner", owner);
                    jsonResponse.put("redirect", "TractorOwnerDashboard.jsp");
                } else { // Default to Farmer
                    session.setAttribute("farmer", farmer);
                    jsonResponse.put("redirect", "FarmerDashboard.jsp");
                }
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Invalid email or password");
            }
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Server error: " + e.getMessage());
        }

        out.print(jsonResponse.toString());
        out.flush();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

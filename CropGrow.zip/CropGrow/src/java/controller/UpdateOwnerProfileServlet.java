/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;



import dao.VehicleOwnerDAOImpl;
import entities.VehicleOwner;
import helper.ConnectionProvider;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 *
 * @author pc
 */
@WebServlet(name = "UpdateOwnerProfileServlet", urlPatterns = {"/UpdateOwnerProfileServlet"})
public class UpdateOwnerProfileServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            // Read the raw JSON request body
            BufferedReader reader = request.getReader();
            StringBuilder jsonBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonBuilder.append(line);
            }
            String jsonString = jsonBuilder.toString();

            // Debug: Log the received JSON
       

            if (jsonString.isEmpty()) {
                throw new IOException("Empty request body");
            }

            // Parse JSON
            JSONObject json = new JSONObject(jsonString);

            int ownerId = json.getInt("ownerId");
            String fname = json.getString("fname");
            String mname = json.getString("mname");
            String lname = json.getString("lname");
            String mobile = json.getString("mobile");
            String gender = json.getString("gender");
            String address = json.getString("address");

            // Create VehicleOwner object
            VehicleOwner owner = new VehicleOwner(
                ownerId, fname, mname, lname,
                mobile, null, gender, address,
                null, null, null, null // email, reg_date, password, role
            );

            // Update database
            VehicleOwnerDAOImpl ownerDao = new VehicleOwnerDAOImpl(ConnectionProvider.getConnection());
            boolean updated = ownerDao.updateDataById(owner);

            // Prepare JSON response
            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("status", updated ? "success" : "error");
            if (!updated) {
                jsonResponse.put("message", "Database update failed.");
            }

            out.write(jsonResponse.toString());
        } catch (Exception e) {
            // Handle parsing or other errors
            System.err.println("Error processing request: " + e.getMessage());
            e.printStackTrace();

            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Invalid request data: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write(jsonResponse.toString());
        } finally {
            out.flush();
            out.close();
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.VehicleDAOImpl;
import entities.Vehicle;
import helper.ConnectionProvider;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
/**
 *
 * @author pc
 */
@WebServlet(name = "UpdateTractoreDetail", urlPatterns = {"/UpdateTractoreDetail"})
public class UpdateMachineDetail extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();
        
        try {
            StringBuilder jsonBody = new StringBuilder();
            try (BufferedReader reader = request.getReader()) {
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBody.append(line);
                }
            }

            String jsonString = jsonBody.toString();
            if (jsonString.isEmpty()) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Empty request body");
                out.print(jsonResponse.toString());
                return;
            }
            
            JSONObject jsonObject = new JSONObject(jsonBody.toString());
            int tractorId = jsonObject.getInt("tractorId");
            int ownerId = jsonObject.getInt("ownerId");
            String name = jsonObject.getString("tractorName");
            int category = jsonObject.getInt("tractorCategory");
            String model = jsonObject.getString("tractorModel");
            String number = jsonObject.getString("tractorNumber");

            StringBuilder validationErrors = new StringBuilder();
            boolean isValid = true;

            // Validate tractor name
            if (name == null || name.trim().isEmpty()) {
                validationErrors.append("Tractor name is required. ");
                isValid = false;
            } else if (name.length() > 100) {
                validationErrors.append("Tractor name is too long. ");
                isValid = false;
            }

            // Validate tractor model
            if (model == null || model.trim().isEmpty()) {
                validationErrors.append("Tractor model is required. ");
                isValid = false;
            } else if (model.length() > 100) {
                validationErrors.append("Tractor model is too long. ");
                isValid = false;
            }

            // Validate category
            if (category <= 0) {
                validationErrors.append("Tractor category is required. ");
                isValid = false;
            }

            // Validate tractor number
            if (number == null || number.trim().isEmpty()) {
                validationErrors.append("Tractor number is required. ");
                isValid = false;
            } else if (number.length() > 20) {
                validationErrors.append("Tractor number is too long. ");
                isValid = false;
            }

            // If validation failed, return error response
            if (!isValid) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", validationErrors.toString());
                out.print(jsonResponse.toString());
                return;
            }
          
          Vehicle vehicle=new Vehicle();
          vehicle.setMid(tractorId);
          vehicle.setmOwnerId(ownerId);
          vehicle.setmName(name);
          vehicle.setmModel(model);
          vehicle.setmNumbe(number);
          vehicle.setmCatgoryId(category);
           
          VehicleDAOImpl dao=new VehicleDAOImpl(ConnectionProvider.getConnection());
         if (dao.UpdateTractorDetail(vehicle)) {
                jsonResponse.put("status", "success");
                jsonResponse.put("message", "Tractor updated successfully.");
            } else {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Failed to update tractor.");
            }
            
            out.print(jsonResponse.toString());
            
        } catch (Exception e) {
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Server error: " + e.getMessage());
            out.print(jsonResponse.toString());
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

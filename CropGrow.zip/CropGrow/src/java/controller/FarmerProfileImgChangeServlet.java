/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.FarmerDAOImpl;
import helper.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author Ashwin
 */
@WebServlet("/ProfileImgChangeServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class FarmerProfileImgChangeServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "C:\\Users\\Admin\\Documents\\NetBeansProjects\\CropGrow\\web\\img\\";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");

        // Get farmer ID
        String farmerIdStr = request.getParameter("farmerId");
        
        if (farmerIdStr == null || farmerIdStr.trim().isEmpty()) {
            response.getWriter().write("{\"status\":\"error\",\"message\":\"Farmer ID is required\"}");
            return;
        }
        int fid = Integer.parseInt(farmerIdStr);

        // Get uploaded file
        Part filePart = request.getPart("profileImage");
        if (filePart == null || filePart.getSize() == 0) {
            response.getWriter().write("{\"status\":\"error\",\"message\":\"Image file is required\"}");
            return;
        }

        // Validate file type (e.g., allow only images)
        String contentType = filePart.getContentType();
        if (!contentType.startsWith("image/")) {
            response.getWriter().write("{\"status\":\"error\",\"message\":\"Only image files are allowed (e.g., JPG, PNG)\"}");
            return;
        }

        // Validate file size (already limited by @MultipartConfig, but explicit check for clarity)
        long fileSize = filePart.getSize();
        if (fileSize > 10 * 1024 * 1024) { // 10MB
            response.getWriter().write("{\"status\":\"error\",\"message\":\"File size exceeds 10MB limit\"}");
            return;
        }

        // Extract original filename and create a unique new filename
        String fileName = filePart.getSubmittedFileName();
        String newFileName = fid + "_" + System.currentTimeMillis() + "_" + fileName;

        // Get the old image name from the database
        FarmerDAOImpl farmerDAO = new FarmerDAOImpl(ConnectionProvider.getConnection());
        String oldImageName = farmerDAO.getProfileImageName(fid); // New method to fetch old image name

        // Delete the old image if it exists and isn’t the default
        if (oldImageName != null && !oldImageName.equals("Default.jpg")) {
            File oldImageFile = new File(UPLOAD_DIR + oldImageName);
            if (oldImageFile.exists()) {
                oldImageFile.delete();
            }
        }

        // Save the new image to the img/ directory
        filePart.write(UPLOAD_DIR + newFileName);

        // Update database with the new image name
        boolean success = farmerDAO.changeProfileImg(fid, newFileName);

        // Send response
        if (success) {
            response.getWriter().write("{\"status\":\"success\",\"message\":\"Image updated successfully\"}");
        } else {
            // If database update fails, delete the newly uploaded file to maintain consistency
            File newImageFile = new File(UPLOAD_DIR + newFileName);
            if (newImageFile.exists()) {
                newImageFile.delete();
            }
            response.getWriter().write("{\"status\":\"error\",\"message\":\"Failed to update image in database\"}");
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

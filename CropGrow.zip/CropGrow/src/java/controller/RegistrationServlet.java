/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.FarmerDAOImpl;
import entities.Farmer;
import helper.ConnectionProvider;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.regex.Pattern;
import org.json.JSONObject;

/**
 *
 * @author Ashwin
 */
public class RegistrationServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private FarmerDAOImpl fDao;

    @Override
    public void init()
            throws ServletException {
        try {
            Connection con = ConnectionProvider.getConnection();
            fDao = new FarmerDAOImpl(con);
        } catch (Exception e) {
            throw new ServletException("Cannot initialize FarmerDAO", e);
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        try {
            // Get form parameters
            String fname = request.getParameter("fname");
            String mname = request.getParameter("mname");
            String lname = request.getParameter("lname");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");
            String mobile = request.getParameter("mobile");
            String email = request.getParameter("email");
            String gender = request.getParameter("gender");
            String address = request.getParameter("address");
            String role = request.getParameter("role");

            // Server-side validation
            if (fname == null || fname.trim().isEmpty() || !fname.matches("^[a-zA-Z\\s]+$")) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Invalid first name");
            } else if (lname == null || lname.trim().isEmpty() || !lname.matches("^[a-zA-Z\\s]+$")) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Invalid last name");
            } else if (password == null || password.length() < 8
                    || !Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$").matcher(password).matches()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Password must be 8+ chars with uppercase, lowercase, and number");
            } else if (!password.equals(confirmPassword)) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Passwords do not match");
            } else if (mobile == null || !mobile.matches("\\d{10}")) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Mobile number must be 10 digits");
            } else if (email == null || !Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$").matcher(email).matches()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Invalid email address");
            } else if (gender == null || !gender.matches("^(Male|Female|Other)$")) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Invalid gender selection");
            } else if (address == null || address.trim().length() < 5) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Address must be at least 5 characters");
            } else if (fDao.isEmailExists(email)) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Email already registered");
            } else {
                // Create Farmer object
                Farmer farmer = new Farmer(1, fname, mname, lname, mobile, email, gender, address,null,password,role,null);
                // Insert into database
                boolean inserted = fDao.registerFarmer(farmer);

                if (inserted) {
                    jsonResponse.put("success", true);
                    System.out.println("Farmer registered: " + email);
                } else {
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "Failed to register farmer in database");
                }
            }
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Server error: " + e.getMessage());
            e.printStackTrace();
        }

        // Send JSON response
        out.print(jsonResponse.toString());
        out.flush();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

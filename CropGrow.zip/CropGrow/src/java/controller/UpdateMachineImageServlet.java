package servlets;

import dao.VehicleDAOImpl;
import org.json.JSONObject;
import helper.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(name = "UpdateTractorImageServlet", urlPatterns = {"/UpdateTractorImageServlet"})
@MultipartConfig(maxFileSize = 1024 * 1024 * 10) // 10MB max file size
public class UpdateMachineImageServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "img";
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        System.out.println("servlets.UpdateMachineImageServlet.doPost()");
 
        PreparedStatement ps = null;

        try {
            // Get tractorId from form data
            String tractorIdStr = request.getParameter("tractorId");
            if (tractorIdStr == null || tractorIdStr.trim().isEmpty()) {
                Part tractorIdPart = request.getPart("tractorId");
                if (tractorIdPart != null) {
                    tractorIdStr = new String(tractorIdPart.getInputStream().readAllBytes()).trim();
                }
            }
            int tractorId = Integer.parseInt(tractorIdStr);
            System.out.println("Received tractorId: " + tractorId); // Debug log

            // Get the uploaded file
            Part filePart = request.getPart("tractorImage");
            String fileName = filePart.getSubmittedFileName();
            if (fileName == null || fileName.isEmpty()) {
                throw new IOException("No file uploaded");
            }

            // Generate a unique file name to avoid conflicts
//            String extension = fileName.substring(fileName.lastIndexOf("."));
//            String newFileName = "tractor_" + tractorId + "_" + System.currentTimeMillis() + extension;
            String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;

            // Create upload directory if it doesn't exist
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }

            // Save the file to the server
            String filePath = "D:/CropGro/CropGrow/CropGrow/web/img/"+ fileName;
            filePart.write(filePath);
            System.out.println("File saved at: " + filePath); // Debug log

            // Update the database with the new image name
           
                    VehicleDAOImpl dao=new VehicleDAOImpl(ConnectionProvider.getConnection());
                     boolean rowsAffected= dao.UpdateMachineImage(tractorId, fileName);
           
            JSONObject jsonResponse = new JSONObject();
            if (rowsAffected) {
                jsonResponse.put("status", "success");
                jsonResponse.put("message", "Tractor image updated successfully.");
                jsonResponse.put("imageName", fileName); // Return the new image name for UI update
            } else {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Failed to update tractor image. No rows affected.");
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                // Clean up the uploaded file if the update fails
                new File(filePath).delete();
            }

            out.print(jsonResponse.toString());
            out.flush();

        } 
        catch (Exception e) {
                e.printStackTrace();
            }
        }
    
}
package controller;
import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import dao.MachineTypeDaoImpl;
import helper.ConnectionProvider;
import entities.MachineType;

@WebServlet("/EditCategoryServlet")
public class EditCategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        JSONObject jsonResponse = new JSONObject();

        try {
            // Read JSON data from request
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = request.getReader();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            JSONObject jsonData = new JSONObject(sb.toString());

            // Get form values
            int mcId = jsonData.getInt("mc_id");
            String mcName = jsonData.getString("mc_name");
            String mcUse = jsonData.getString("mc_use");
            double mcRate = jsonData.getDouble("mc_rate");

            // Server-side validation
            if (mcId <= 0) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Invalid category ID");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            
            if (mcName == null || mcName.trim().isEmpty()) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Category name is required");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcName.length() < 5) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Category name must be at least 5 characters long");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcName.length() > 100) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Category name must be less than 100 characters");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcUse == null || mcUse.trim().isEmpty()) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Description is required");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcUse.length() < 10) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Description must be at least 10 characters long");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcRate <= 0) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Rate must be a positive number");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            if (mcRate >= 1200) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Rate is not greater than 1200");
                response.getWriter().write(jsonResponse.toString());
                return;
            }

            // Check if category exists
            MachineTypeDaoImpl dao = new MachineTypeDaoImpl(ConnectionProvider.getConnection());
            MachineType existingCategory = dao.getMachineTypeById(mcId);
            
            if (existingCategory == null) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Category not found");
                response.getWriter().write(jsonResponse.toString());
                return;
            }

            // Create MachineType object with updated values
            MachineType machineType = new MachineType();
            machineType.setMcId(mcId);
            machineType.setMcName(mcName);
            machineType.setMcUse(mcUse);
            machineType.setMc_rate(mcRate);
            machineType.setMcImg(existingCategory.getMcImg()); // Keep existing image

            // Update in database
            boolean updated = dao.updateMachineType(machineType);

            if (updated) {
                jsonResponse.put("status", "success");
                jsonResponse.put("message", "Category updated successfully");
                jsonResponse.put("categoryId", mcId);
            } else {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Failed to update category in database");
            }

        } catch (Exception e) {
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Server error: " + e.getMessage());
            e.printStackTrace();
        }

        response.getWriter().write(jsonResponse.toString());
    }
}
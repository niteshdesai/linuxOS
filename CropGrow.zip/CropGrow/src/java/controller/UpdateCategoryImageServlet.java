import dao.AdminDAOImpl;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.json.JSONObject;
import dao.MachineTypeDaoImpl;
import helper.ConnectionProvider;
import entities.MachineType;

@WebServlet("/UpdateCategoryImageServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                maxFileSize = 1024 * 1024 * 10,      // 10MB
                maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class UpdateCategoryImageServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "img";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        JSONObject jsonResponse = new JSONObject();
        
        try {
            // Get category ID
            String mcId = request.getParameter("mc_id");
            int categoryId = Integer.parseInt(mcId);
            
            // Get uploaded file
            Part filePart = request.getPart("mc_img");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            
            // Validate inputs
            if (fileName.isEmpty()) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "No file selected");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            
            // Validate file type
            String contentType = filePart.getContentType();
            if (!contentType.startsWith("image/")) {
                jsonResponse.put("status", "error");
                jsonResponse.put("message", "Invalid file type. Please upload an image.");
                response.getWriter().write(jsonResponse.toString());
                return;
            }
            

            
            // Save file
            String filePath = "D:/CropGro/CropGrow/CropGrow/web/img/"+ fileName;
            filePart.write(filePath);
            

            AdminDAOImpl adao =new AdminDAOImpl(ConnectionProvider.getConnection());

          
                boolean updated = adao.updateCategoryImage(categoryId, fileName);
                
                if (updated) {
                    jsonResponse.put("status", "success");
                    jsonResponse.put("imageName", fileName);
                    jsonResponse.put("imageUrl", "D:/CropGro/CropGrow/CropGrow/web/img/" + fileName);
                } else {
                    jsonResponse.put("status", "error");
                    jsonResponse.put("message", "Failed to update database");
                }
            } 
            
         catch (NumberFormatException e) {
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Invalid category ID");
            e.printStackTrace();
        } catch (Exception e) {
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Server error: " + e.getMessage());
            e.printStackTrace();
        }
        
        response.getWriter().write(jsonResponse.toString());
    }
}
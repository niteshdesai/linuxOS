/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


$(document).ready(function () {
    function fetchData() {
        $.ajax({
            url: 'LocationServlet',
            method: 'GET',
            success: function (response) {
                $('#data-container').html(response);
            },
            error: function () {
                $('#data-container').html('<p>Error fetching data</p>');
            }
        });
    }

    // Fetch data initially and then every 5 seconds
    fetchData();
    setInterval(fetchData, 5000);
});

// Handle form submission
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const form = e.target;
    
    // Validate passwords match
    if (form.password.value !== form.confirmPassword.value) {
        alert('Passwords do not match!');
        return;
    }
    
    // Get location coordinates
    try {
        const position = await getCurrentPosition();
        form.latitude.value = position.coords.latitude;
        form.longitude.value = position.coords.longitude;
        
        // Submit form
        const formData = new FormData(form);
        
        const response = await fetch('../api/user', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            alert('Registration successful! Please login.');
            window.location.href = 'login.jsp';
        } else {
            const error = await response.json();
            throw new Error(error.message || 'Registration failed');
        }
    } catch (error) {
        console.error('Error during registration:', error);
        alert(error.message || 'Failed to register. Please try again.');
    }
});

// Get current position
function getCurrentPosition() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocation is not supported by your browser'));
            return;
        }

        navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        });
    });
}

// Validate password strength
document.getElementById('password').addEventListener('input', (e) => {
    const password = e.target.value;
    const strength = checkPasswordStrength(password);
    updatePasswordStrengthIndicator(strength);
});

// Check password strength
function checkPasswordStrength(password) {
    let strength = 0;
    
    if (password.length >= 8) strength++;
    if (password.match(/[a-z]/)) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;
    
    return strength;
}

// Update password strength indicator
function updatePasswordStrengthIndicator(strength) {
    const indicator = document.getElementById('passwordStrength');
    const strengthText = ['Very Weak', 'Weak', 'Medium', 'Strong', 'Very Strong'];
    const strengthColors = ['#ff4444', '#ffbb33', '#ffeb3b', '#00C851', '#007E33'];
    
    indicator.textContent = strengthText[strength - 1] || 'Very Weak';
    indicator.style.color = strengthColors[strength - 1] || '#ff4444';
}

// Validate phone number
document.getElementById('phone').addEventListener('input', (e) => {
    const phone = e.target.value;
    const isValid = /^[0-9]{10}$/.test(phone);
    
    if (!isValid) {
        e.target.setCustomValidity('Please enter a valid 10-digit phone number');
    } else {
        e.target.setCustomValidity('');
    }
});

// Auto-fill address based on coordinates
async function getAddressFromCoordinates(latitude, longitude) {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
        const data = await response.json();
        return data.display_name;
    } catch (error) {
        console.error('Error getting address:', error);
        return '';
    }
}

// Update address field when coordinates change
document.getElementById('latitude').addEventListener('change', updateAddress);
document.getElementById('longitude').addEventListener('change', updateAddress);

async function updateAddress() {
    const latitude = document.getElementById('latitude').value;
    const longitude = document.getElementById('longitude').value;
    
    if (latitude && longitude) {
        const address = await getAddressFromCoordinates(latitude, longitude);
        document.getElementById('address').value = address;
    }
} 
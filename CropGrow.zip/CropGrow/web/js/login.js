document.addEventListener('DOMContentLoaded', function() {
    // Toggle password visibility
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.querySelector('#password');

    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }

    // Form validation
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Get form values
            const email = document.querySelector('#email').value;
            const password = document.querySelector('#password').value;
            const userType = document.querySelector('#userType').value;
            const remember = document.querySelector('input[name="remember"]').checked;

            // Basic validation
            if (!email || !password || !userType) {
                showError('Please fill in all required fields');
                return;
            }

            // Email validation
            if (!isValidEmail(email)) {
                showError('Please enter a valid email address');
                return;
            }

            // Password validation
            if (password.length < 6) {
                showError('Password must be at least 6 characters long');
                return;
            }

            // Create form data
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('userType', userType);
            formData.append('remember', remember);

            // Send login request
            fetch('../api/user/login', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Store user data in session storage
                    sessionStorage.setItem('userData', JSON.stringify(data.user));
                    
                    // Redirect based on user type
                    switch(userType) {
                        case 'FARMER':
                            window.location.href = 'farmer-dashboard.jsp';
                            break;
                        case 'TRACTOR_OWNER':
                            window.location.href = 'owner-dashboard.jsp';
                            break;
                        case 'ADMIN':
                            window.location.href = 'admin-dashboard.jsp';
                            break;
                    }
                } else {
                    showError(data.message || 'Login failed. Please try again.');
                }
            })
            .catch(error => {
                showError('An error occurred. Please try again later.');
                console.error('Login error:', error);
            });
        });
    }
});

// Helper function to validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Helper function to show error message
function showError(message) {
    // Remove existing error message if any
    const existingError = document.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }

    // Create new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
    `;

    // Insert error message before the form
    const form = document.querySelector('.login-form');
    form.parentNode.insertBefore(errorDiv, form);

    // Remove error message after 5 seconds
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Add input validation feedback
const inputs = document.querySelectorAll('.input-group input, .input-group select');
inputs.forEach(input => {
    input.addEventListener('input', function() {
        if (this.value.trim() !== '') {
            this.classList.add('valid');
        } else {
            this.classList.remove('valid');
        }
    });
}); 
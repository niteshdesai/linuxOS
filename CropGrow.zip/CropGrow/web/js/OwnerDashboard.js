// Check if jQuery is loaded
if (typeof jQuery === 'undefined') {
    console.error('jQuery is not loaded');
} else {
    console.log('jQuery loaded successfully');
}

$(document).ready(function() {
    console.log('Document ready - OwnerDashboard.js loaded');

    // Open modal when clicking elements with data-modal attribute
    $('[data-modal]').on('click', function(e) {
        e.preventDefault();
        console.log('Modal trigger clicked');
        
        const modalId = $(this).data('modal');
        const $modal = $('#' + modalId);
        
        if ($modal.length) {
            console.log('Opening modal:', modalId);
            $modal.addClass('active');
            
            // If edit modal, you could populate form here
            if (modalId === 'edit-tractor-modal') {
                // Example: Populate edit form (add your logic here)
                console.log('Edit modal opened - Add population logic here');
            }
        } else {
            console.error('Modal with ID ' + modalId + ' not found');
        }
    });

    // Close modal when clicking the close button
    $('.modal-close').on('click', function() {
        console.log('Close button clicked');
        const $modal = $(this).closest('.modal');
        $modal.removeClass('active');
    });

    // Close modal when clicking outside the modal content
    $('.modal').on('click', function(e) {
        if ($(e.target).hasClass('modal')) {
            console.log('Clicked outside modal');
            $(this).removeClass('active');
        }
    });

    // Handle tractor form submission
    $('#submit-tractor').on('click', function(e) {
        e.preventDefault();
        console.log('Submit tractor clicked');
        
        const $form = $('#add-tractor-form');
        if (!$form[0].checkValidity()) {
            console.log('Form validation failed');
            $form[0].reportValidity();
            return;
        }

        const formData = new FormData();
        formData.append('name', $('#tractor-name').val());
        formData.append('type', $('#tractor-type').val());
        formData.append('year', $('#tractor-year').val());
        formData.append('hours', $('#tractor-hours').val());
        formData.append('status', $('#tractor-status').val());
        const imageFile = $('#tractor-image')[0].files[0];
        if (imageFile) {
            formData.append('image', imageFile);
            console.log('Image file added to form data');
        }

        // AJAX request to add tractor
        $.ajax({
            url: '${pageContext.request.contextPath}/api/tractors/add',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log('Tractor added successfully:', response);
                alert('Tractor added successfully!');
                $('#add-tractor-modal').removeClass('active');
                $form[0].reset();
            },
            error: function(xhr, status, error) {
                console.error('Error adding tractor:', status, error);
                alert('Error adding tractor: ' + error);
            }
        });
    });

    // Optional: Handle edit tractor form submission
    $('#update-tractor').on('click', function(e) {
        e.preventDefault();
        console.log('Update tractor clicked');
        // Add your edit logic here
        const $modal = $(this).closest('.modal');
        $modal.removeClass('active');
    });
});